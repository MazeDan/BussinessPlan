<?php 
    include_once("../topo.php");
    include_once("../menu.php");
?>
    <a href="produtos.php">Produtos</a>
    <a href="funcionarios.php">funcionarios</a>
    <a href="transacao.php">transacao</a>