<?php 
    include_once("../topo.php");
    include_once("../menu.php");
?>
    <h1>
        total
    </h1>
    
    <a href="produto.php"> Produtos</a>
    <a href="funcionarios.php"> funcionarios</a>
    <a href="transacao.php"> transacao</a>

<?php 

?>