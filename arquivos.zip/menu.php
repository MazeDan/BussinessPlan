 <header>
    <div class="px-3 py-2 text-bg-dark">
      <div class="container">
        <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
          <a href="index.php" class="d-flex align-items-center my-2 my-lg-0 me-lg-auto text-white text-decoration-none">
         
           <img src="https://cdn-icons-png.flaticon.com/512/171/171239.png" width="50">  <h2>  
            BF </h2><h2 class="align-text-bottom" style="color: red;">E</h2>
          </a>

          <ul class="nav col-12 col-lg-auto my-2 justify-content-center my-md-0 text-small text-center">
            <li>
             <a href="inicio.php" class="nav-link <?php if($pindex) echo 'text-secondary'; else echo 'text-white'; ?>">
                <i class="bi bi-house-fill" style="font-size: 2rem; color: cornflowerblue;" ></i><br>
                Inicio
              </a>
            </li>
            
            <li>
              <a href="https://atividadesdan.000webhostapp.com/BFE/adicionar/index.php" class="nav-link <?php if($pisobre) echo 'text-secondary'; else echo 'text-white'; ?>">
                <i class="bi bi-bookmark-fill" style="font-size: 2rem; color: cornflowerblue;" ></i><br>
                Adicionar
              </a>
            </li>
            
            
            <li>
              <a href="https://atividadesdan.000webhostapp.com/BFE/tabela" class="nav-link <?php if($pcontato) echo 'text-secondary'; else echo 'text-white'; ?>">
                 
               <i class="bi bi-table" style="font-size: 2rem; color: cornflowerblue;" ></i><br>
                Tabelas
              </a>
            </li>
            
             
          </ul>
        </div>
      </div>
    </div>
    
  </header>